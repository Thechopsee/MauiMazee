﻿
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiMaze.Engine
{
    public class Hitbox
    {
        public float X { get; set; }
        public float Y { get; set; }
        public float Size { get; set; }
    }
}
