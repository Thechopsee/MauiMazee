﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiMaze.Services
{
    public class ServiceConfig
    {
        public static string serverAdress = "http://10.0.0.23:8087/";
        public static string SMTP_name = "";
        public static string SMTP_pass = "";
    }
}
