﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace MauiMaze.Helpers
{
    public enum RoleEnum
    {
        User,
        Admin,
        Reseacher,
    }
}
